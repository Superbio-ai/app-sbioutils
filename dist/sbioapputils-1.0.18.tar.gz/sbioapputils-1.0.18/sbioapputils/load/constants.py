# -*- coding: utf-8 -*-
TABULAR_EXTENSIONS = ['csv','tsv','txt']
SC_EXTENSIONS = ['h5','h5ad','h5Seurat']
TABULAR_PANDAS_FORMATS = ['pandas', 'pd']
TABULAR_NUMPY_FORMATS = ['numpy', 'np']
SC_TARGET_FORMATS = ['anndata']